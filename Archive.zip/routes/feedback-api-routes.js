var db = require("../models");

module.exports = function(app) {

};
